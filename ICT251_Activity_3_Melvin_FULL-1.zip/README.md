# ICT251 Activity 3 — Interactive Personal Website

Student: Melvin Ngandwe  
Programme: Computer Science  
University: Mulungushi University  
Course: ICT251 Web Technologies

## What is included
- Original Activity 2 personal content retained and enhanced.
- Three personal photographs in `images/`.
- Responsive HTML5 structure.
- External CSS in `css/styles.css`.
- JavaScript in `js/script.js`.
- Contact form validation and local preview.
- Gallery Previous/Next viewer.
- Project/skills search and reset.
- Mobile navigation.
- Expandable project details.
- Light/dark theme switch.
- README documentation.

## IMPORTANT BEFORE FINAL SUBMISSION
The Activity 2 requirements specify:
- `videos/intro.mp4`: a 30–60 second introduction video about Melvin, his Computer Science programme and one web skill he hopes to learn.
- `videos/voice.mp3`: a 15–30 second recording about one hobby or the reason for studying web technologies.

The two files are currently empty placeholders because the student's original recordings were not provided. Replace them with the student's own recordings before uploading the final repository.

Suggested video script:
"Hello, my name is Melvin Ngandwe. I am a Computer Science student at Mulungushi University. In ICT251 Web Technologies, I am learning how to create well-structured and responsive websites using HTML, CSS and JavaScript. One skill I hope to improve is building interactive websites that can be used by other people. Thank you."

Suggested audio script:
"One of my hobbies is coding and practising programming. I enjoy learning how software and websites are created. Studying web technologies is important to me because it helps me build practical projects and improve my Computer Science skills."

## JavaScript features
1. Contact form validation and local preview.
2. Gallery viewer with Previous and Next.
3. Project/skills search and Reset.
4. Mobile navigation.
5. Expandable project details.
6. Light/dark theme switch.

## Local testing
Use VS Code Live Server. Check navigation, images, media, form validation, gallery buttons, search/filter, mobile menu, theme switch, keyboard focus and browser Console errors.

## Render settings
Root Directory: blank  
Build Command: `echo "No build required"`  
Publish Directory: `.`  
Auto Deploy: enabled

After deployment, make one small improvement, commit it to GitHub, wait for Render to redeploy, and confirm the change on the same live URL.
