// ICT251 Activity 3 - interactive portfolio features

const $ = (selector) => document.querySelector(selector);

// Feature 1: Mobile navigation
const menuButton = $("#menuButton");
const mainNav = $("#mainNav");
menuButton.addEventListener("click", () => {
    const isOpen = mainNav.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(isOpen));
    menuButton.textContent = isOpen ? "✕ Close" : "☰ Menu";
});
mainNav.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
        mainNav.classList.remove("open");
        menuButton.setAttribute("aria-expanded", "false");
        menuButton.textContent = "☰ Menu";
    });
});

// Feature 2: Contact form validation and local preview
const form = $("#contactForm");
form.addEventListener("submit", (event) => {
    event.preventDefault();

    const name = $("#name");
    const email = $("#email");
    const message = $("#message");
    const nameError = $("#nameError");
    const emailError = $("#emailError");
    const messageError = $("#messageError");
    const preview = $("#formPreview");

    nameError.textContent = "";
    emailError.textContent = "";
    messageError.textContent = "";
    preview.hidden = true;

    let valid = true;
    const cleanName = name.value.trim();
    const cleanMessage = message.value.trim();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!cleanName) {
        nameError.textContent = "Please enter your name.";
        valid = false;
    }
    if (!emailPattern.test(email.value.trim())) {
        emailError.textContent = "Please enter a valid email address.";
        valid = false;
    }
    if (!cleanMessage) {
        messageError.textContent = "Please enter a message.";
        valid = false;
    }

    if (valid) {
        preview.textContent = `Validated successfully. Name: ${cleanName}. Email: ${email.value.trim()}. Message: ${cleanMessage}`;
        preview.hidden = false;
    }
});

// Feature 3: Gallery viewer
const galleryPhotos = [
    {src: "images/photo1.jpg", alt: "Personal photo 1", caption: "Photo 1 — Personal portfolio photo"},
    {src: "images/photo2.jpg", alt: "Personal photo 2", caption: "Photo 2 — Personal portfolio photo"},
    {src: "images/photo3.jpg", alt: "Personal photo 3", caption: "Photo 3 — Personal portfolio photo"}
];
let currentPhoto = 0;
const galleryImage = $("#galleryImage");
const galleryCaption = $("#galleryCaption");
const galleryCounter = $("#galleryCounter");

function showPhoto(index) {
    currentPhoto = index;
    const photo = galleryPhotos[currentPhoto];
    galleryImage.src = photo.src;
    galleryImage.alt = photo.alt;
    galleryCaption.textContent = photo.caption;
    galleryCounter.textContent = `${currentPhoto + 1} / ${galleryPhotos.length}`;
}
$("#prevPhoto").addEventListener("click", () => {
    showPhoto((currentPhoto - 1 + galleryPhotos.length) % galleryPhotos.length);
});
$("#nextPhoto").addEventListener("click", () => {
    showPhoto((currentPhoto + 1) % galleryPhotos.length);
});

// Feature 4: Project/skills filter
const searchInput = $("#projectSearch");
const resetSearch = $("#resetSearch");
const cards = [...document.querySelectorAll(".project-card")];
const filterMessage = $("#filterMessage");

function filterProjects() {
    const query = searchInput.value.trim().toLowerCase();
    let visible = 0;
    cards.forEach(card => {
        const matches = card.dataset.search.includes(query);
        card.hidden = !matches;
        if (matches) visible++;
    });
    filterMessage.textContent = query
        ? `${visible} result${visible === 1 ? "" : "s"} found.`
        : "Showing all projects and skills.";
}
searchInput.addEventListener("input", filterProjects);
resetSearch.addEventListener("click", () => {
    searchInput.value = "";
    filterProjects();
    searchInput.focus();
});

// Expandable project details
document.querySelectorAll(".details-button").forEach(button => {
    button.addEventListener("click", () => {
        const details = button.nextElementSibling;
        const open = !details.hidden;
        details.hidden = open;
        button.setAttribute("aria-expanded", String(!open));
        button.textContent = open ? "Show details" : "Hide details";
    });
});

// Optional theme switch via keyboard shortcut: press T.
// A visible button is added so the feature is obvious to the visitor.
const themeButton = document.createElement("button");
themeButton.type = "button";
themeButton.className = "button secondary";
themeButton.textContent = "Toggle Theme";
themeButton.style.position = "fixed";
themeButton.style.right = "16px";
themeButton.style.bottom = "16px";
themeButton.style.zIndex = "20";
document.body.appendChild(themeButton);

function toggleTheme() {
    document.body.classList.toggle("dark");
}
themeButton.addEventListener("click", toggleTheme);
